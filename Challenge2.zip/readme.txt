Enter any valid email of lenght more than 9 characters
Enter any password of more than 6 characters
when the above conditions are met the form will redirect you to challenge3(to-do-list)