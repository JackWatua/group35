The to do list uses session storage to store data 
Type on the Title and task input then click on add Task
To do list tasks will appear below the input fields
NB: once the browser window is closed the to do task will be deleted and will not be there when the page is opened again.