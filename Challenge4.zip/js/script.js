var transaction_options = [
    "Deposit Cash",
    "Withdraw Cash",
    "Check Balance",
    "You Exited!",
];

let change_header = function (transaction){
    switch (transaction){
        case "deposit": 
            var header = transaction_options[0];
            break;
        case "withdrawal":
            var header = transaction_options[1];
            break;
        case "exit" : 
            var header = transaction_options[3];
            break;
        default:
            var header = transaction_options[2];
            break;
    }
    document.getElementById("header").innerText = header;
}

//Make  a function that displays current tab based on user clicks
let toogle_tab = function (tab) {
    //When the user clicks an option eg(withdraw or deposit) display the specific transaction window
    document.getElementById(tab).style = "display : block;";
    //Change the header
    change_header(tab);
    //Hide the landing page view
    document.getElementById('content').style = "display : none;"
}



function navigate_back(current_tab){
    //hide current tab
    document.getElementById(current_tab).style.display = "none";
    //reset the main UI 
    document.getElementById("content").style =null;
}

function get_date(){
    //get tranaction date
    var transaction_date = new Date();
    var time = transaction_date.toLocaleTimeString();
    var date= transaction_date.toLocaleDateString();
    return date + " " + time;
}



//Set up a default user account
user_account = [
    {
        'user_balance' : 0,
        'last_access_date': "",
        'user_pin' : 1234,
        'transaction_time' : get_date(),
    }
];



let deposit_cash = function (){
    //get the value af casg deposited
    var amount = document.deposit_form.Amount.value;
    //add amount deposited to the user's balance
    user_account[0]['user_balance'] += parseInt(amount);
    return user_account[0]["user_balance"];
}

let withdraw_cash = function (){
    //get the value af cash deposited
    var amount = document.withdrawal_form.Amount.value;
    var pin =  document.withdrawal_form.Password.value;
    if (pin != user_account[0]["user_pin"]){
        document.getElementById("message").innerText = `Invalid Pin!Refresh and try again`;
        document.getElementById("withdrawal_message").style.backgroundColor = "red";
        return;
    }else{
        if (parseInt(amount) > user_account[0]["user_balance"]){
            document.getElementById("withdrawal_message").style.backgroundColor = "red";
            document.getElementById("message").innerText = `Cannot Withdraw ${amount} from your account!Your balance is ${user_account[0]['user_balance']}`;
            return;
        }
        document.getElementById("withdrawal_message").style.backgroundColor = "green";
        user_account[0]['user_balance'] -= parseInt(amount);
        document.getElementById("message").innerText = `You have Withdrawn ${amount} from your account!Your new balance is ${user_account[0]['user_balance']}`;
        return user_account[0]["user_balance"];
    }
}


let check_balance = function (){
    get_balance();
    return user_account[0]["user_balance"];
}

let get_balance  = function (){
    document.getElementById("bal").innerText = user_account[0]["user_balance"];
} 

let set_withdrawal_pin = function (){
    var pin = prompt("Set transaction pin (4 digits)")
    user_account[0]["user_pin"] = pin;
    if (pin == ""){
        alert("PIN cannot be blank!");
        return 0;
    }else if (pin.length < 4){
        alert("PIN too short! ");
        return 0;
    }
    return user_account[0]["user_pin"];
}
function exit(){
    document.getElementById("transaction_time").innerText = `Your Account was last accessed on ${user_account[0]['transaction_time']}`;
}
set_withdrawal_pin();
