var user_name = "";
var user_password = "";
var confirm_password = "";



const setup_profile = function (){
    user_name = prompt("Enter your User Name ");
    user_password = prompt("Enter Password  ");
    confirm_password = prompt("Confirm Password ");
    if (!(user_password == confirm_password)) {
        alert ("Passwords must match!")
        return;
    }else if (user_password.length < 8 | confirm_password.length < 8){
        alert ("Password too Short!");
        return;
    }
    if  (user_name == ""){
        alert("User name Cannot be blank!");
        return;
    }
    alert ("Profile Created Succeffully. Please Log In to continue!");
    return user_name, confirm_password;
}




setup_profile()

let verify_login = () => {
    //Get user name and password from form
    var name = document.login_form.user_name.value;
    var password = document.login_form.Password.value;
    if (name == user_name & password == user_password){
        document.getElementById("log_in_message").innerText = "Log In Successful"
        document.getElementById("message").style = "display: block;  background-color: green;";
        window.location = "http://127.0.0.1:5500/index.html"
    }else{
        document.getElementById("log_in_message").innerText = "Log In Unsuccessful!"
        document.getElementById("message").style = "display: block;  background-color: red;";
    }

}
